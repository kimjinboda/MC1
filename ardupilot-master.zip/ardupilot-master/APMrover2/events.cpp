#include "Rover.h"

void Rover::update_events(void)
{
    ServoRelayEvents.update_events();
}
