
This is the second generation ppm encoder code designed for APM v1.x boards using ATMega328P.

