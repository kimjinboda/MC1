Please see http://ardupilot.org/plane/docs/airframe-disco.html for
more information on setting up a Parrot Disco
